# Cadastro usando Room

Foi desenvolvido uma aplicação Android utilizando arquitetura baseada em Fragments e persistência de dados com Room.
